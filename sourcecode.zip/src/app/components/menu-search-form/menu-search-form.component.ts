import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-search-form',
  templateUrl: './menu-search-form.component.html',
  styleUrls: ['./menu-search-form.component.scss']
})
export class MenuSearchFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
