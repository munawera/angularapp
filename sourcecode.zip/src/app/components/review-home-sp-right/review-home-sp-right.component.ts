import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-review-home-sp-right',
  templateUrl: './review-home-sp-right.component.html',
  styleUrls: ['./review-home-sp-right.component.scss']
})
export class ReviewHomeSpRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
